{\rtf1\ansi\ansicpg1252\cocoartf2758
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 Abhinav Vinod\
avinod34@gatech.edu\
Canvas: Abhinav Vinod\
\
Main Scene: Minigame\
\
In the build, one may notice the Roll-A-Ball Game with certain changes. These changes include a slighty more zoomed in Main Camera to accomodate for objects overhead of the player as they move. The Player object can also jump with the SPACE key as well as the other movement for the keys in the tutorial. There are some platforms up which I have placed collectables to collect and complete the game. These collectables now osciallte in place as well as rotate. Some platforms also oscillate. There are some blue rocks on the ground as well and the whole scene is now inside a closed shape with walls. Small edits were made to the Player script to add jumpoing functionality. The camera script was also slightly modified to add zoom. The Osciallte script was created to add oscialltion to objects. The rotate script was left untouched.}