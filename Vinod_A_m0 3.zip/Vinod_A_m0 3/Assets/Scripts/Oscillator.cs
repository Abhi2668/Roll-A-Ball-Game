using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Oscillator : MonoBehaviour
{
    public float speed = 1.0f; // Speed of the oscillation
    public float height = 0.5f; // Max height of the oscillation

    private Vector3 startPosition;

    void Start()
    {
        startPosition = transform.position;
    }

    void Update()
    {
        Vector3 newPosition = startPosition;
        newPosition.y += Mathf.Sin(Time.time * speed) * height;
        transform.position = newPosition;
    }
}
